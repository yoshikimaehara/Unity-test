﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class Room : MonoBehaviour {

    public List<Room> connectRoom = new List<Room>();
    public List<Room> nextToAreaList = new List<Room>();
    public List<Room> preConnectRoom = new List<Room>();
    public List<Room> aroundRoom = new List<Room>();
    public int connDis;
    public bool isConnectCheck = false;
    public int aisleSize = 0;
    public int aislePositionX = 0;
    public int aislePositionY = 0;

    public const int NONE = 0;    // 無し
    public const int AISLE = 1;   // 通路
    public const int ROOM = 2;    // 部屋

    public int ROOM_SIZE_X = 10;
    public int ROOM_SIZE_Y = 10;

    public const int ROOM_VER_MIN = 5;
    public const int ROOM_HOR_MIN = 5;
    public const int ROOM_VER_MAX = 8;
    public const int ROOM_HOR_MAX = 8;
    public const int X_FLOOR_SIZE = 5;
    public const int Y_FLOOR_SIZE = 5;

    private List<List<bool>> floorList = new List<List<bool>>();
    private int numberX;
    private int numberY;
    private int roomType = 0;   // 部屋の種類　0:無し 1:通路 2:部屋
    private int VerSize = 0;    // 縦軸の大きさ 
    private int HorSize = 0;    // 横軸の大きさ
    private int positionX = 0;  // X軸の位置
    private int positionY = 0;  // Y軸の位置


    public int getNumberX()
    {
        return numberX;
    }

    public int getNumberY()
    {
        return numberY;
    }

    public string toString()
    {
        return "my position X:" + numberX + "Y:" + numberY;
    }

    private void roomInit()
    {
        for (int y = 0; y < 10; y++)
        {
            for (int x = 0; x < 10; x++)
            {
                floorList[y][x] = false;
            }
        }
    }

    public Room(int numberX, int numberY)
    {
        this.numberX = numberX;
        this.numberY = numberY;
    }

    public void setRoomType(int type) {
        roomType = type;
    }

    public int getRoomType()
    {
        return roomType;
    }

    public void setAroundRoom(Room aroundRoom)
    {
        try
        {
            this.aroundRoom.Add(aroundRoom);
        }
        catch (System.ArgumentOutOfRangeException e)
        {
            this.aroundRoom.Add(null);
        }
    }

    public void roomGenerate()
    {
        GameObject floor = (GameObject)Resources.Load("Prehabs/Floor1");

        // 部屋の縦サイズの決定
        VerSize = Random.Range(ROOM_VER_MIN, ROOM_VER_MAX);

        // 部屋の横サイズの決定
        HorSize = Random.Range(ROOM_HOR_MIN, ROOM_HOR_MAX);

        //部屋の位置の決定
        positionY = Random.Range(1, ROOM_VER_MAX - VerSize);
        positionX = Random.Range(1, ROOM_HOR_MAX - HorSize);
        Debug.Log("Room No. " + numberY + "-" + numberX + "sizeX : " + HorSize);
        Debug.Log("Room No. " + numberY + "-" + numberX + "sizeY : " + VerSize);
        Debug.Log("Room No. " + numberY + "-" + numberX + "X : " + positionX);
        Debug.Log("Room No. " + numberY + "-" + numberX + "Y : " + positionY);

        for (int y = positionY; y < positionY + VerSize; y++)
        {
            for (int x = positionX; x < positionX + HorSize; x++)
            {
                // 床の配置
                Instantiate(floor, new Vector3(numberX * 50 + x * 5, numberY * 50 + y * 5), Quaternion.identity);
            }

        }

    }

    /// <summary>
    /// 通路の生成処理
    /// </summary>
    /// <param name="direction"></param>
    public void aisleGenerate(Room destinationRoom)
    {
        int retrunPoint;
        Debug.Log("通路をかいてくよー");
        GameObject aisleFloor = (GameObject)Resources.Load("Prehabs/Floor1");
        isConnectCheck = true; //探索のRoomに設定する
        Room currentRoom = this;
        getAislePositions(currentRoom.connDis);

        while (true)
        {
            Debug.Log("今の部屋はx: " + currentRoom.getNumberX() + "y: " + currentRoom.getNumberY());
            
            if(Object.ReferenceEquals(currentRoom.aroundRoom[currentRoom.connDis], destinationRoom))
            {

                layFloorEnd(currentRoom, currentRoom.aroundRoom[currentRoom.connDis], Room.ROOM, currentRoom.connDis);
                Debug.Log("通路書き終わったよー");
                return;
            }

            Debug.Log("方向: " + currentRoom.connDis);
            retrunPoint = Random.Range(4, ROOM_SIZE_X);
            layFloor(currentRoom, currentRoom.connDis, retrunPoint);
            currentRoom = currentRoom.aroundRoom[currentRoom.connDis];

            Debug.Log("次の部屋はx: " + currentRoom.getNumberX() + "y: " + currentRoom.getNumberY());

        }


    }

    private void getAislePositions(int direction)
    {
        switch (direction)
        {
            case Map.UP:
                aislePositionX = Random.Range(positionX, positionX + HorSize);
                aislePositionY = positionY + VerSize;
                break;
            case Map.RIGHT:
                aislePositionX = positionX + HorSize;
                aislePositionY = Random.Range(positionY, positionY + VerSize);

                break;
            case Map.DOWN:
                aislePositionX = Random.Range(positionX, positionX + HorSize);
                aislePositionY = positionY;

                break;
            case Map.LEFT:
                aislePositionX = positionX;
                aislePositionY = Random.Range(positionY, positionY + VerSize);
                break;
        }
    }

    private void layFloor(Room room, int direction,int retrunPoint)
    {

        GameObject aisleFloor = (GameObject)Resources.Load("Prehabs/Floor1");
        aisleSize = Random.Range(1, 3);
       

        int tmpAislePositionY = aislePositionY;
        int tmpAislePositionX = aislePositionX;

        switch (direction)
        {
            case Map.UP:
                while (aislePositionY < ROOM_SIZE_Y + retrunPoint)
                {
                    while (aislePositionX < tmpAislePositionX + aisleSize)
                    {
                        Instantiate(aisleFloor, new Vector3(room.getNumberX() * 50 + aislePositionX * 5, room.getNumberY() * 50 + aislePositionY * 5), Quaternion.identity);
                        aislePositionX++;
                    }
                    aislePositionX = tmpAislePositionX;
                    aislePositionY++;
                }
                aislePositionY = retrunPoint;
                break;
            case Map.RIGHT:
                while (aislePositionX < ROOM_SIZE_X + retrunPoint)
                {
                    while (aislePositionY < tmpAislePositionY + aisleSize)
                    {
                        Instantiate(aisleFloor, new Vector3(room.getNumberX() * 50 + aislePositionX * 5, room.getNumberY() * 50 + aislePositionY * 5), Quaternion.identity);
                        aislePositionY++;
                    }
                    aislePositionY = tmpAislePositionY;
                    aislePositionX++;
                }
                aislePositionX = retrunPoint;
                break;
            case Map.DOWN:
                retrunPoint = (-retrunPoint);
                while (aislePositionY > retrunPoint)
                {
                    while (aislePositionX < tmpAislePositionX + aisleSize)
                    {
                        Instantiate(aisleFloor, new Vector3(room.getNumberX() * 50 + aislePositionX * 5, room.getNumberY() * 50 + aislePositionY * 5), Quaternion.identity);
                        aislePositionX++;
                    }
                    aislePositionX = tmpAislePositionX;
                    aislePositionY--;
                }
                aislePositionY = (-retrunPoint);
                break;
            case Map.LEFT:
                retrunPoint = (-retrunPoint);
                while (aislePositionX > retrunPoint)
                {
                    while (aislePositionY < tmpAislePositionY + aisleSize)
                    {
                        Instantiate(aisleFloor, new Vector3(room.getNumberX() * 50 + aislePositionX * 5, room.getNumberY() * 50 + aislePositionY * 5), Quaternion.identity);
                        aislePositionY++;
                    }
                    aislePositionY = tmpAislePositionY;
                    aislePositionX--;
                }
                aislePositionX = (-retrunPoint);
                break;
        }
        
    }

    private void endLayFloor(Room room, int direction, int retrunPoint)
    {

        GameObject aisleFloor = (GameObject)Resources.Load("Prehabs/Floor1");
        aisleSize = Random.Range(1, 3);


        int tmpAislePositionY = aislePositionY;
        int tmpAislePositionX = aislePositionX;

        switch (direction)
        {
            case Map.UP:
                while (aislePositionY < retrunPoint)
                {
                    while (aislePositionX < tmpAislePositionX + aisleSize)
                    {
                        Instantiate(aisleFloor, new Vector3(room.getNumberX() * 50 + aislePositionX * 5, room.getNumberY() * 50 + aislePositionY * 5), Quaternion.identity);
                        aislePositionX++;
                    }
                    aislePositionX = tmpAislePositionX;
                    aislePositionY++;
                }
                aislePositionY = retrunPoint;
                break;
            case Map.RIGHT:
                while (aislePositionX < retrunPoint)
                {
                    while (aislePositionY < tmpAislePositionY + aisleSize)
                    {
                        Instantiate(aisleFloor, new Vector3(room.getNumberX() * 50 + aislePositionX * 5, room.getNumberY() * 50 + aislePositionY * 5), Quaternion.identity);
                        aislePositionY++;
                    }
                    aislePositionY = tmpAislePositionY;
                    aislePositionX++;
                }
                aislePositionX = retrunPoint;
                break;
            case Map.DOWN:
                retrunPoint = (-retrunPoint);
                while (aislePositionY > retrunPoint)
                {
                    while (aislePositionX < tmpAislePositionX + aisleSize)
                    {
                        Instantiate(aisleFloor, new Vector3(room.getNumberX() * 50 + aislePositionX * 5, room.getNumberY() * 50 + aislePositionY * 5), Quaternion.identity);
                        aislePositionX++;
                    }
                    aislePositionX = tmpAislePositionX;
                    aislePositionY--;
                }
                aislePositionY = (-retrunPoint);
                break;
            case Map.LEFT:
                retrunPoint = (-retrunPoint);
                while (aislePositionX > retrunPoint)
                {
                    while (aislePositionY < tmpAislePositionY + aisleSize)
                    {
                        Instantiate(aisleFloor, new Vector3(room.getNumberX() * 50 + aislePositionX * 5, room.getNumberY() * 50 + aislePositionY * 5), Quaternion.identity);
                        aislePositionY++;
                    }
                    aislePositionY = tmpAislePositionY;
                    aislePositionX--;
                }
                aislePositionX = (-retrunPoint);
                break;
        }

    }

    private void layFloorEnd(Room currentRoom,Room nextToRoom, int Roomtype, int direction)
    {
        int endX = 0;
        int endY = 0;
        int returnPoint = 0;
        int connDis = -1;
        Debug.Log("部屋と部屋をつなぐんご");
        Debug.Log("方向: " + direction);
        if (direction == Map.UP || direction == Map.DOWN)
        {
            endX = Random.Range(nextToRoom.positionX, nextToRoom.positionX + nextToRoom.HorSize);

            if (direction == Map.UP)
            {
                endY = nextToRoom.positionY;
            }
            else if(direction == Map.DOWN)
            {
                endY = nextToRoom.positionY + nextToRoom.VerSize;
            }

            if (aislePositionY < endY)
            {
                connDis = Map.RIGHT;
            }
            else if (aislePositionY < endY)
            {
                connDis = Map.LEFT;
            }
            else if (aislePositionX == endX)
            {

                layFloor(currentRoom, currentRoom.connDis, endY);
                return;
            }

            returnPoint = Random.Range(ROOM_SIZE_Y - aislePositionY, endY);
            endLayFloor(currentRoom, direction, returnPoint);
            endLayFloor(currentRoom, connDis, returnPoint);
            endLayFloor(currentRoom, direction, endY);

        }

        else if(direction == Map.RIGHT || direction == Map.LEFT)
        {
            endY = Random.Range(nextToRoom.positionY, positionY + nextToRoom.VerSize);

            if (direction == Map.RIGHT)
            {
                endX = nextToRoom.positionX;
            }
            else if (direction == Map.LEFT)
            {
                endX = nextToRoom.positionX + nextToRoom.HorSize;
            }


            if (aislePositionY < endY)
            {
                connDis = Map.UP;
            }
            else if (aislePositionY < endY)
            {
                connDis = Map.DOWN;
            }
            else if(aislePositionY == endY)
            {

                layFloor(currentRoom, currentRoom.connDis, endX);
                return;
            }
    
            returnPoint = Random.Range(ROOM_SIZE_X - aislePositionX, endX);
            endLayFloor(currentRoom, currentRoom.connDis, returnPoint);
            endLayFloor(currentRoom, connDis, returnPoint);
            endLayFloor(currentRoom, currentRoom.connDis, endX);
            

        }
        

    }
}

