﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

// Mapの自動作成をつくろう！

public class Map : MonoBehaviour {
    public const int VERTIVAL = 3;      // 横軸
    public const int HORIZONTAL = 5;    // 縦軸
    public const int MAXROOMVALUE = 10; // 1Map当たりの最大部屋数 
    public const int MINROOMVALUE = 5;  // 1Map当たりの最小部屋数   

    public const int UP = 0;
    public const int RIGHT = 1;
    public const int DOWN = 2;
    public const int LEFT = 3;

    private List<List<Room>> roomGroup = new List<List<Room>>();
    private double roomProbability = 0.3;       // 部屋生成確率
    public int roomValue = 0;   
    


    // Room instance の生成
	public void initMap(){
        for (int y = 0; y < VERTIVAL; y++)
        {
            List<Room> tmpRoomList = new List<Room>();
            for (int x = 0; x < HORIZONTAL; x++)
            {
                Debug.Log("Gen X: " + x + "Y: " + y);
                Room tmpRoom = new Room(x,y);
                tmpRoomList.Add(tmpRoom);
            }
            roomGroup.Add(tmpRoomList);          
        }
    }

    public void mapGenerate()
    {
        // 最小部屋数を満たすまで部屋の生成を繰り返す
        while (roomValue < MINROOMVALUE)
        {
            for (int y = 0; y < VERTIVAL; y++)
            {
                for (int x = 0; x < HORIZONTAL; x++)
                {
                    Debug.Log("X: " + x + "Y: " + y);

                    // 周囲の部屋の設定
                    try
                    {
                        roomGroup[y][x].aroundRoom.Add(roomGroup[y + 1][x]);
                    }
                    catch (System.ArgumentOutOfRangeException e)
                    {
                        roomGroup[y][x].setAroundRoom(null);
                    }

                    try
                    {
                        roomGroup[y][x].setAroundRoom(roomGroup[y][x + 1]);
                    }
                    catch (System.ArgumentOutOfRangeException e)
                    {
                        roomGroup[y][x].setAroundRoom(null);
                    }

                    try
                    {
                        roomGroup[y][x].setAroundRoom(roomGroup[y - 1][x]);
                    }
                    catch (System.ArgumentOutOfRangeException e)
                    {
                        roomGroup[y][x].setAroundRoom(null);
                    }

                    try
                    {
                        roomGroup[y][x].setAroundRoom(roomGroup[y][x - 1]);
                    }
                    catch (System.ArgumentOutOfRangeException e)
                    {
                        roomGroup[y][x].setAroundRoom(null);
                    }

                    // 部屋の生成決定
                    if (isPlaceRoom(roomGroup[y][x]))
                    {
                        // 部屋の生成処理
                        roomGroup[y][x].setRoomType(Room.ROOM);
                        roomGroup[y][x].connectRoom.Add(roomGroup[y][x]);
                        roomGroup[y][x].roomGenerate();   
                        roomValue++;
                    }
                }                 
            }
            // 部屋の生成確率を上げる
            roomProbability = roomProbability * 2;
        }
        
        // 通路の生成処理
        for (int y = 0; y < VERTIVAL; y++)
        {
            for (int x = 0; x < HORIZONTAL; x++)
            {
                if (!roomGroup[y][x].isConnectCheck && roomGroup[y][x].getRoomType() == Room.ROOM)
                {
                    Debug.Log("今の部屋:" + x + "," + y);
                    int searchDirection;
                    List<int> passableArea = new List<int>() { UP, LEFT, DOWN, RIGHT };
                    int nextToLocationX = x;
                    int nextToLocationY = y;
                    int currentLocationX = x;
                    int currentLocationY = y;

                    int roopCounter = 0;

                    while (true)
                    {
                        bool isNextToAreaFlg = true;
                        roopCounter++;
                        // 探索方向の決定

                        if (roopCounter > 30)
                        {
                            Debug.Log("無限ループにはまってます");
                            break;
                        }

                        // 行き止まりになった場合
                        if (passableArea.Count == 0)
                        {
                            Debug.Log("x :" + currentLocationX + "y :" + currentLocationY + "行き止まり");
                            passableArea = new List<int>() { UP, LEFT, DOWN, RIGHT };
                            roomGroup[currentLocationY][currentLocationX].setRoomType(Room.NONE);

                            int preNum = roomGroup[currentLocationY][currentLocationX].nextToAreaList.Count - 1;
                            Room preRoom = roomGroup[currentLocationY][currentLocationX].nextToAreaList[preNum];

                            // 前の部屋の隣接部屋リストから削除
                            preRoom.nextToAreaList.Remove(roomGroup[currentLocationY][currentLocationX]);

                            // 前の部屋が部屋かつほかの部屋とつながっている場合
                            if (preRoom.getRoomType() == Room.ROOM
                                && preRoom.nextToAreaList.Count != 0)
                            {
                                break;
                            }

                            // 前の部屋が通路ではない場合は前の部屋に戻り以前に通った方向以外から探索開始
                            currentLocationY = preRoom.getNumberY();
                            currentLocationX = preRoom.getNumberX();
                            passableArea.Remove(preRoom.connDis);
                            continue;
                        }

                        searchDirection = passableArea[Random.Range(0, (passableArea.Count - 1))];

                        switch (searchDirection)
                        {
                            case UP:
                                nextToLocationY = currentLocationY + 1;
                                nextToLocationX = currentLocationX;
                                break;
                            case RIGHT:
                                nextToLocationX = currentLocationX + 1;
                                nextToLocationY = currentLocationY;
                                break;
                            case DOWN:
                                nextToLocationY = currentLocationY - 1;
                                nextToLocationX = currentLocationX;
                                break;
                            case LEFT:
                                nextToLocationX = currentLocationX - 1;
                                nextToLocationY = currentLocationY;
                                break;
                        }



                        Debug.Log("方向 : " + searchDirection);

                        // Y軸のチェック
                        if ((nextToLocationY) >= VERTIVAL || nextToLocationY < 0)
                        {
                            Debug.Log("x :" + (nextToLocationX) + "y :" + (nextToLocationY) + "Yがだめ");
                            passableArea.Remove(searchDirection);
                            continue;
                        }

                        // X軸のチェック
                        if ((nextToLocationX >= HORIZONTAL || nextToLocationX < 0))
                        {
                            Debug.Log("x :" + (nextToLocationX) + "y :" + (nextToLocationY) + "Xがだめ");
                            passableArea.Remove(searchDirection);
                            continue;
                        }

                        Debug.Log("次の探索 x: " + (nextToLocationX) + "y: " + (nextToLocationY));
                        if(containRoom(roomGroup[currentLocationY][currentLocationX].connectRoom,
                            roomGroup[nextToLocationY][nextToLocationX].connectRoom))
                        {
                            Debug.Log("x :" + (nextToLocationX) + "y :" + (nextToLocationY) + "もうとおったよ");
                            passableArea.Remove(searchDirection);
                            continue;
                        }
                        
                        // 既に探索ずみのroomだった場合


                        
                        if (roomGroup[nextToLocationY][nextToLocationX].getRoomType() == Room.ROOM
                            || roomGroup[nextToLocationY][nextToLocationX].getRoomType() == Room.AISLE)
                        {
                            Debug.Log("今の部屋:" + x + "," + y);
                            Debug.Log("隣の部屋:" + (nextToLocationX) + "," + (nextToLocationY));
                            roomGroup[currentLocationY][currentLocationX].nextToAreaList.Add(roomGroup[nextToLocationY][nextToLocationX]);
                            roomGroup[nextToLocationY][nextToLocationX].nextToAreaList.Add(roomGroup[currentLocationY][currentLocationX]);
                            connListCopyToNextArea(roomGroup[currentLocationY][currentLocationX].connectRoom, roomGroup[nextToLocationY][nextToLocationX]);
                            connListCopyToNextArea(roomGroup[nextToLocationY][nextToLocationX].connectRoom, roomGroup[currentLocationY][currentLocationX]);
                            roomGroup[currentLocationY][currentLocationX].connDis = searchDirection;
                            roomGroup[y][x].aisleGenerate(roomGroup[nextToLocationY][nextToLocationX]);
                            passableArea = new List<int>() { UP, LEFT, DOWN, RIGHT };
                            break;
                        }
                        else if (roomGroup[nextToLocationY][nextToLocationX].getRoomType() == Room.NONE)
                        {
                            Debug.Log("x :" + (nextToLocationY) + "y :" + (nextToLocationX) + "通路に設定");
                            roomGroup[nextToLocationY][nextToLocationX].setRoomType(Room.AISLE);
                            roomGroup[currentLocationY][currentLocationX].connDis = searchDirection;
                            roomGroup[currentLocationY][currentLocationX].nextToAreaList.Add(roomGroup[nextToLocationY][nextToLocationX]);
                            roomGroup[nextToLocationY][nextToLocationX].connectRoom.AddRange(roomGroup[currentLocationY][currentLocationX].connectRoom);
                            roomGroup[nextToLocationY][nextToLocationX].nextToAreaList.Add(roomGroup[currentLocationY][currentLocationX]);
                            passableArea = new List<int>() { UP, LEFT, DOWN, RIGHT };
                            currentLocationY = nextToLocationY;
                            currentLocationX = nextToLocationX;
                            continue;
                        }
                    }
                }
            }
        }

        Debug.Log("部屋数 : " + roomValue);

    }

    private bool isPlaceRoom(Room room)
    {
        // 既に部屋の生成がされている場合
        if (room.getRoomType() == Room.ROOM)
        {
            return false;
        }
        // 部屋数の最大値を満たしている場合
        if (roomValue > MAXROOMVALUE)
        {
            return false;
        }
        // 乱数生成
        if (Random.value > roomProbability)
        {
            return false;
        }
        return true;
    }

    /// <summary>
    /// 隣のエリアへ接続状況をコピーする。
    /// </summary>
    /// <param name="copyConnRoomList"></param>
    /// <param name="toCopyArea"></param>
    private void connListCopyToNextArea(List<Room> copyConnRoomList,Room toCopyArea)
    {
        toCopyArea.connectRoom.AddRange(copyConnRoomList);
        for(int i = 0; i < toCopyArea.nextToAreaList.Count; i++)
        {
            if (!containRoom(copyConnRoomList,toCopyArea.nextToAreaList[i].connectRoom))
            {
                Debug.Log("x: " + toCopyArea.nextToAreaList[i].getNumberX() + "y: " + toCopyArea.nextToAreaList[i].getNumberY() + "にコピーするよ");
                connListCopyToNextArea(copyConnRoomList, toCopyArea.nextToAreaList[i]);
            }
        }
    }

    /// <summary>
    /// checkAreaがcheckRoomListに含まれているかチェックする。
    /// 含まれている場合はtrueを返します。それ以外はfalseを返します。
    /// </summary>
    /// <param name="checkRoomList"></param>
    /// <param name="checkArea"></param>
    private bool containRoom(List<Room> checkRoomList, Room checkArea)
    {
        for(int i = 0; i < checkRoomList.Count; i++)
        {
            Object.ReferenceEquals(checkRoomList[i], checkArea);
            return true;
        }
        return false;
    }


    private bool containRoom(List<Room> checkRoomList, List<Room> checkArea)
    {
        int count = 0;
        for (int i = 0; i < checkRoomList.Count; i++)
        {
            for(int j = 0; j < checkArea.Count; j++)
            {
                if (Object.ReferenceEquals(checkRoomList[i], checkArea[j]))
                {
                    // Listの中にcheck対象が含まれていた場合はcountする。
                    ++count;
                    break;
                }
            }
        }
        
        // countがcheck対象数を満たしていた場合
        if(count >= checkRoomList.Count)
        {
            Debug.Log("counter :" + count + "checkCount :" + checkArea.Count);
            return true; 
        }

        return false;
    }

}
